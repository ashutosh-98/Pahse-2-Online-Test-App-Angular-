import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { ReactiveFormsModule} from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginEventComponent } from './login-event/login-event.component';
import { StartPageComponent } from './start-page/start-page.component';
// import { TestPageComponent } from './test-page/test-page.component';
import { QuestionSetComponent } from './question-set/question-set.component';
import { TestEndComponent } from './test-end/test-end.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SignUpComponent } from './sign-up/sign-up.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginEventComponent,
    StartPageComponent,
    // TestPageComponent,
    QuestionSetComponent,
    TestEndComponent,
    PageNotFoundComponent,
    SignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
